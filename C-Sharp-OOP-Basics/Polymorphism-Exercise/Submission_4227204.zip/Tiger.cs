﻿using System;

public class Tiger : Felime
{
    public Tiger(string animalName, double animalWeight,  string livingRegion)
        : base(animalName, animalWeight, livingRegion)
    {
    }

    public override string MakeSound()
    {
        return "ROAAR!!!";
    }

    public override void EatFood(Food food)
    {
        if (food is Meat)
        {
            this.FoodEaten += food.Quantity;
        }
        else
        {
            throw new ArgumentException($"{this.GetType().Name}s are not eating that type of food!");
        }
    }

    public override string ToString()
    {
        return
            $"{this.GetType().Name}[{this.AnimalName}, {this.AnimalWeight}, {this.LivingRegion}, {this.FoodEaten}]";
    }
}
