﻿using System;

public class Mouse : Mammal
{
    public Mouse(string animalName, double animalWeight, string livingRegion) : base(animalName, animalWeight, livingRegion)
    {
    }

    public override string MakeSound()
    {
        return "SQUEEEAAAK!";
    }

    public override void EatFood(Food food)
    {
        if (food is Vegetable)
        {
            this.FoodEaten += food.Quantity;
        }
        else
        {
            throw new ArgumentException($"{this.GetType().Name}s are not eating that type of food!");
        }       
    }

    public override string ToString()
    {
        return
            $"{this.GetType().Name}[{this.AnimalName}, {this.AnimalWeight}, {this.LivingRegion}, {this.FoodEaten}]";
    }
}
