﻿public abstract class Animal
{
    private string animalName;
    private double animalWeight;

    protected Animal(string animalName, double animalWeight)
    {
        this.animalName = animalName;
        this.animalWeight = animalWeight;
    }

    public int FoodEaten { get; protected set; }

    public double AnimalWeight
    {
        get { return this.animalWeight; }
        set { this.animalWeight = value; }
    }


    public string AnimalName
    {
        get { return this.animalName; }
        set { this.animalName = value; }
    }

    public abstract string MakeSound();

    public abstract void EatFood(Food food);
}
