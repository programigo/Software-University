﻿public class Cat : Felime
{
    private string breed;

    public Cat(string animalName, double animalWeight, string livingRegion, string breed) : base(animalName, animalWeight, livingRegion)
    {
        this.breed = breed;
    }

    public override string MakeSound()
    {
        return "Meowwww";
    }

    public override void EatFood(Food food)
    {
        this.FoodEaten += food.Quantity;
    }

    public override string ToString()
    {
        return
            $"{this.GetType().Name}[{this.AnimalName}, {this.breed}, {this.AnimalWeight}, {this.LivingRegion}, {this.FoodEaten}]";
    }
}