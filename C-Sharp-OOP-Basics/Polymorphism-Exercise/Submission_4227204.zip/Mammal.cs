﻿public abstract class Mammal : Animal
{
    private string livingRegion;


    public Mammal(string animalName, double animalWeight, string livingRegion) : base(animalName, animalWeight)
    {
        this.livingRegion = livingRegion;
    }

    public string LivingRegion
    {
        get { return this.livingRegion; }
        set { this.livingRegion = value; }
    }
}
