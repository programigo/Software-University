﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.WildFarm
{
    public class Startup
    {
        public static void Main()
        {
            string input;

            while ((input = Console.ReadLine()) != "End")
            {

                Animal animal = CreateAnimal(input);

                Food food = CreateFood(Console.ReadLine());

                Console.WriteLine(animal.MakeSound());

                try
                {
                    animal.EatFood(food);
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                
                Console.WriteLine(animal);

            }
        }

        private static Animal CreateAnimal(string input)
        {
            var animalInfo = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            string type = animalInfo[0];
            string name = animalInfo[1];
            double weight = double.Parse(animalInfo[2]);
            string livingRegion = animalInfo[3];

            if (type == "Mouse")
            {
                return new Mouse(name, weight, livingRegion);
            }
            if (type == "Zebra")
            {
                return new Zebra(name, weight, livingRegion);
            }
            if (type == "Tiger")
            {
                return new Tiger(name, weight, livingRegion);
            }

            string breed = animalInfo[4];
            return new Cat(name, weight, livingRegion, breed);
        }

        private static Food CreateFood(string input)
        {
            var foodInfo = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            string type = foodInfo[0];
            int quantity = int.Parse(foodInfo[1]);

            if (type == "Vegetable")
            {
                return new Vegetable(quantity);
            }

            return new Meat(quantity);
        }
    }

}



