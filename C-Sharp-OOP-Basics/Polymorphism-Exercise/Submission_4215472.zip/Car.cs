﻿public class Car : Vehicle
{
    public Car(double fuelQuantity, double fuelConsumption) : base(fuelQuantity, fuelConsumption)
    {
    }

    public override double FuelConsumption
    {
        get { return base.FuelConsumption + 0.9; }
    }

    public override double FuelQuantity
    {
        get { return base.FuelQuantity; }
    }

    public override string Drive(double distance)
    {
        if (this.FuelConsumption * distance <= this.FuelQuantity)
        {
            this.FuelQuantity -= this.FuelConsumption * distance;

            return $"Car travelled {distance} km";
        }

        return "Car needs refueling";
    }

    public override void Refuel(double liters)
    {
        this.FuelQuantity += liters;
    }

    public override string ToString()
    {
        return $"Car: {this.FuelQuantity:f2}";
    }
}
