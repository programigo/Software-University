﻿public abstract class Vehicle
{
    private double fuelQuantity;
    private double fuelConsumption;

    public Vehicle(double fuelQuantity, double fuelConsumption)
    {
        this.FuelQuantity = fuelQuantity;
        this.FuelConsumption = fuelConsumption;
    }

    public virtual double FuelConsumption { get; set; }
  

    public virtual double FuelQuantity {get; set;}

    public abstract string Drive(double distance);

    public abstract void Refuel(double liters);
}
