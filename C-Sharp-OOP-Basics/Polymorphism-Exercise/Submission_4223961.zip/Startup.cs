﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Vehicles
{
    public class Startup
    {
        public static void Main()
        {
            string[] carInfo = Console.ReadLine().Split(' ');
            Vehicle car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]), double.Parse(carInfo[3]));

            string[] truckInfo = Console.ReadLine().Split(' ');
            Vehicle truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]), double.Parse(truckInfo[3]));

            string[] busInfo = Console.ReadLine().Split(' ');
            Bus bus = new Bus(double.Parse(busInfo[1]), double.Parse(busInfo[2]), double.Parse(busInfo[3]));

            int numberOfCommands = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfCommands; i++)
            {
                try
                {
                    string[] commandElements = Console.ReadLine().Split(' ');


                    if (commandElements[0] == "Drive")
                    {
                        double distance = double.Parse(commandElements[2]);

                        if (commandElements[1] == "Car")
                        {
                            Console.WriteLine(car.Drive(distance));
                        }
                        else if (commandElements[1] == "Truck")
                        {
                            Console.WriteLine(truck.Drive(distance));
                        }
                        else if (commandElements[1] == "Bus")
                        {
                            Console.WriteLine(bus.Drive(distance));
                        }
                    }
                    else if (commandElements[0] == "DriveEmpty")
                    {
                        double distance = double.Parse(commandElements[2]);
                        Console.WriteLine(bus.DriveEmpty(distance));
                    }
                    else if (commandElements[0] == "Refuel")
                    {
                        double liters = double.Parse(commandElements[2]);

                        if (commandElements[1] == "Car")
                        {
                            car.Refuel(liters);
                        }
                        else if (commandElements[1] == "Truck")
                        {
                            truck.Refuel(liters);
                        }
                        else if (commandElements[1] == "Bus")
                        {
                            bus.Refuel(liters);
                        }
                    }
                }
                catch (ArgumentException ae)
                {
                    Console.WriteLine(ae.Message);
                }

            }
            Console.WriteLine(car);
            Console.WriteLine(truck);
            Console.WriteLine(bus);
        }
    }
}
