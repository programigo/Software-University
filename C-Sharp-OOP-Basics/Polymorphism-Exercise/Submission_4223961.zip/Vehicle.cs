﻿using System;

public abstract class Vehicle
{
    private double fuelQuantity;
    private double fuelConsumption;
    private double tankCapacity;

    public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity)
    {
        this.FuelQuantity = fuelQuantity;
        this.FuelConsumption = fuelConsumption;
        this.TankCapacity = tankCapacity;
    }

    public virtual double FuelConsumption { get; set; }

    public virtual double TankCapacity { get; set; }

    public virtual double FuelQuantity
    {
        get { return this.tankCapacity; }
        set
        {
            if (value < 0)
            {
                throw new ArgumentException("Fuel must be a positive number");
            }

            this.tankCapacity = value;
        }
    }

    public abstract string Drive(double distance);

    public abstract void Refuel(double liters);
}
