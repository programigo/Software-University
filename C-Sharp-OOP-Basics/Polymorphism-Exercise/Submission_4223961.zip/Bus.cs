﻿using System;

public class Bus : Vehicle
{
    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption, tankCapacity)
    {
    }

    public override string Drive(double distance)
    {

        if ((this.FuelConsumption + 1.4) * distance <= this.FuelQuantity)
        {
            this.FuelQuantity -= (this.FuelConsumption + 1.4) * distance;

            return $"Bus travelled {distance} km";
        }

        return "Bus needs refueling";
    }

    public string DriveEmpty(double distance)
    {
        if (this.FuelConsumption * distance <= this.FuelQuantity)
        {
            this.FuelQuantity -= this.FuelConsumption * distance;

            return $"Bus travelled {distance} km";
        }

        return "Bus needs refueling";
    }

    public override void Refuel(double liters)
    {
        if (liters <= 0)
        {
            throw new ArgumentException("Fuel must be a positive number");
        }

        if (this.TankCapacity < liters)
        {
            throw new ArgumentException("Cannot fit fuel in tank");
        }
        else
        {
            this.FuelQuantity += liters;
        }
    }

    public override string ToString()
    {
        return $"Bus: {this.FuelQuantity:f2}";
    }
}
