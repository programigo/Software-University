﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Shapes
{
    public class Startup
    {
        public static void Main()
        {
            double rectHeight = double.Parse(Console.ReadLine());
            double rectWidth = double.Parse(Console.ReadLine());

            Shape rectangle = new Rectangle(rectHeight, rectWidth);

            Console.WriteLine(rectangle.CalculateArea());
            Console.WriteLine(rectangle.CalculatePerimeter());
            Console.WriteLine(rectangle.Draw());
        }
    }
}
